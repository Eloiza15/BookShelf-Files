﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace BookShelf
{
    public class Livro
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Editora { get; set; }
        public string Categoria { get; set; }
        public string CapaUrl { get; set; }

        public bool SalvarLivro()
        {
            try
            {


                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string inserir = "insert into livros (titulo, autor, editora, categoria) value (@titulo, @autor, @editora, @categoria)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    
                    comando.Parameters.AddWithValue("@titulo", Titulo);
                    comando.Parameters.AddWithValue("@autor", Autor);
                    comando.Parameters.AddWithValue("@editora", Editora);
                    comando.Parameters.AddWithValue("@categoria", Categoria);

                    

                    int resultado = comando.ExecuteNonQuery();

                    if (resultado > 0)
                    {
                        MessageBox.Show("Livro salvado com sucesso");
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Não foi possivel salvar o livro");
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao salvar livro. " + ex.Message);
                return false;
            }
        }

        public bool ListarLivros(DataGridView dataGrid)
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string listar = "select * from livros";
                    MySqlCommand comando = new MySqlCommand(listar, conexaoBanco);
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    dataGrid.DataSource = tabela;

                    // Configurações do DataGridView
                    dataGrid.AllowUserToAddRows = false;  // Impede a adição de novas linhas manualmente
                    dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;  // Ajusta as colunas automaticamente
                    dataGrid.AutoResizeColumns();  // Redimensiona as colunas
                    dataGrid.ClearSelection();  // Limpa a seleção das células

                    if (dataGrid.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao listar livro. " + ex.Message);
                return false;
            }
        }
    }
}