using System;
using System.Windows.Forms;
using TesteGoogleBooksAPI; // <- nome do seu namespace


namespace TesteAPIGoogle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnBuscar_Click(object sender, EventArgs e)
        {
            var api = new GoogleBooksAPI();
            var livro = await api.BuscarLivroPorTitulo(txtTituloBusca.Text);

            if (livro == null)
            {
                MessageBox.Show("Livro n�o encontrado.");
                return;
            }

            txtTitulo.Text = livro.Titulo;
            txtAutor.Text = livro.Autor;
            txtEditora.Text = livro.Editora;
            txtCategoria.Text = livro.Categoria;

            if (!string.IsNullOrEmpty(livro.CapaUrl))
                picCapa.Load(livro.CapaUrl);
        }
    }
}
