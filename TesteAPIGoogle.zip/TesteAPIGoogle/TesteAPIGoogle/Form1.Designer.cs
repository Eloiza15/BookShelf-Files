﻿namespace TesteAPIGoogle
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblBuscar = new Label();
            txtTituloBusca = new TextBox();
            btnBuscar = new Button();
            lblTitulo = new Label();
            txtTitulo = new TextBox();
            lblAutor = new Label();
            txtAutor = new TextBox();
            lblEditora = new Label();
            txtEditora = new TextBox();
            lblCategoria = new Label();
            txtCategoria = new TextBox();
            lblCapa = new Label();
            picCapa = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)picCapa).BeginInit();
            SuspendLayout();
            // 
            // lblBuscar
            // 
            lblBuscar.AutoSize = true;
            lblBuscar.Location = new Point(100, 62);
            lblBuscar.Name = "lblBuscar";
            lblBuscar.Size = new Size(191, 25);
            lblBuscar.TabIndex = 0;
            lblBuscar.Text = "Digite o título do livro:";
            // 
            // txtTituloBusca
            // 
            txtTituloBusca.Location = new Point(327, 62);
            txtTituloBusca.Name = "txtTituloBusca";
            txtTituloBusca.Size = new Size(202, 31);
            txtTituloBusca.TabIndex = 1;
            // 
            // btnBuscar
            // 
            btnBuscar.Location = new Point(417, 420);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(112, 34);
            btnBuscar.TabIndex = 2;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(100, 160);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(60, 25);
            lblTitulo.TabIndex = 3;
            lblTitulo.Text = "Título:";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(177, 154);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(150, 31);
            txtTitulo.TabIndex = 4;
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.Location = new Point(99, 204);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(61, 25);
            lblAutor.TabIndex = 5;
            lblAutor.Text = "Autor:";
            // 
            // txtAutor
            // 
            txtAutor.Location = new Point(177, 204);
            txtAutor.Name = "txtAutor";
            txtAutor.Size = new Size(150, 31);
            txtAutor.TabIndex = 6;
            // 
            // lblEditora
            // 
            lblEditora.AutoSize = true;
            lblEditora.Location = new Point(88, 257);
            lblEditora.Name = "lblEditora";
            lblEditora.Size = new Size(72, 25);
            lblEditora.TabIndex = 7;
            lblEditora.Text = "Editora:";
            // 
            // txtEditora
            // 
            txtEditora.Location = new Point(177, 251);
            txtEditora.Name = "txtEditora";
            txtEditora.Size = new Size(150, 31);
            txtEditora.TabIndex = 8;
            // 
            // lblCategoria
            // 
            lblCategoria.AutoSize = true;
            lblCategoria.Location = new Point(68, 309);
            lblCategoria.Name = "lblCategoria";
            lblCategoria.Size = new Size(92, 25);
            lblCategoria.TabIndex = 9;
            lblCategoria.Text = "Categoria:";
            // 
            // txtCategoria
            // 
            txtCategoria.Location = new Point(186, 316);
            txtCategoria.Name = "txtCategoria";
            txtCategoria.Size = new Size(150, 31);
            txtCategoria.TabIndex = 10;
            // 
            // lblCapa
            // 
            lblCapa.AutoSize = true;
            lblCapa.Location = new Point(683, 139);
            lblCapa.Name = "lblCapa";
            lblCapa.Size = new Size(56, 25);
            lblCapa.TabIndex = 11;
            lblCapa.Text = "Capa:";
            // 
            // picCapa
            // 
            picCapa.Location = new Point(584, 182);
            picCapa.Name = "picCapa";
            picCapa.Size = new Size(289, 180);
            picCapa.TabIndex = 12;
            picCapa.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1054, 582);
            Controls.Add(picCapa);
            Controls.Add(lblCapa);
            Controls.Add(txtCategoria);
            Controls.Add(lblCategoria);
            Controls.Add(txtEditora);
            Controls.Add(lblEditora);
            Controls.Add(txtAutor);
            Controls.Add(lblAutor);
            Controls.Add(txtTitulo);
            Controls.Add(lblTitulo);
            Controls.Add(btnBuscar);
            Controls.Add(txtTituloBusca);
            Controls.Add(lblBuscar);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)picCapa).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblBuscar;
        private TextBox txtTituloBusca;
        private Button btnBuscar;
        private Label lblTitulo;
        private TextBox txtTitulo;
        private Label lblAutor;
        private TextBox txtAutor;
        private Label lblEditora;
        private TextBox txtEditora;
        private Label lblCategoria;
        private TextBox txtCategoria;
        private Label lblCapa;
        private PictureBox picCapa;
    }
}
